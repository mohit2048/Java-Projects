package com.example.cvssScore;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CvssScoreApplication {

	public static void main(String[] args) {
		SpringApplication.run(CvssScoreApplication.class, args);
	}

}
